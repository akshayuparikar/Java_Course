package cdac;


	class BankAccount {
	    String accountNumber;
	    String holderName;
	    double balance;

	    public BankAccount(String accountNumber, String holderName, double balance) {
	        this.accountNumber = accountNumber;
	        this.holderName = holderName;
	        this.balance = balance;
	    }
	    class SavingsAccount extends BankAccount {
	        public SavingsAccount(String acc, String holder, double bal) {
	            super(acc, holder, bal);
	        }
	        public void addInterest(double rate) {
	            balance += balance * rate / 100;
	        }
	    }

	    class CurrentAccount extends BankAccount {
	        public CurrentAccount(String acc, String holder, double bal) {
	            super(acc, holder, bal);
	        }
	        public void applyServiceCharge(double charge) {
	            balance -= charge;
	        }
	    }

	    class BankSystem{
		    public static void main(String[] args) 
		    {
		 
		    	      
		    	        cdac.BankAccount.SavingsAccount savings = new SavingsAccount("SA123", "Alice", 10000.0);
		    	        System.out.println("Initial Savings Balance: ₹" + savings.balance);
		    	        savings.addInterest(5.0); // Add 5% interest
		    	        System.out.println("After Interest: ₹" + savings.balance);

		    	        // Create a CurrentAccount object
		    	        cdac.BankAccount.CurrentAccount current = new CurrentAccount("CA456", "Bob", 8000.0);
		    	        System.out.println("\nInitial Current Balance: ₹" + current.balance);
		    	        current.applyServiceCharge(500.0); // Apply service charge
		    	        System.out.println("After Service Charge: ₹" + current.balance);
		    	    }
		    	
		    }
	}


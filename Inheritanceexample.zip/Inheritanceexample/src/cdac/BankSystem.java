package cdac;
class BankSystem{
	    public static void main(String[] args) 
	    {
	 
	    	      
	    	        cdac.BankAccount.SavingsAccount savings = new cdac.BankAccount.SavingsAccount("SA123", "Alice", 10000.0);
	    	        System.out.println("Initial Savings Balance: ₹" + savings.balance);
	    	        savings.addInterest(5.0); // Add 5% interest
	    	        System.out.println("After Interest: ₹" + savings.balance);

	    	        // Create a CurrentAccount object
	    	        cdac.BankAccount.CurrentAccount current = new cdac.BankAccount.CurrentAccount("CA456", "Bob", 8000.0);
	    	        System.out.println("\nInitial Current Balance: ₹" + current.balance);
	    	        current.applyServiceCharge(500.0); // Apply service charge
	    	        System.out.println("After Service Charge: ₹" + current.balance);
	    	    }
	    	
	    }
	































































}

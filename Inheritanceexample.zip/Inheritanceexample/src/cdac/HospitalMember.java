package cdac;


	public class HospitalMember {
	    String memberId;
	    String name;
	    String department;

	    public HospitalMember(String memberId, String name, String department) {
	        this.memberId = memberId;
	        this.name = name;
	        this.department = department;
	    }
	}

}

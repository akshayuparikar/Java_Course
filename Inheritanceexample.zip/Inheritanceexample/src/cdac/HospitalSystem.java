package cdac;

class HospitalMember {
    String memberId;
    String name;
    String department;

    public HospitalMember(String memberId, String name, String department) {
        this.memberId = memberId;
        this.name = name;
        this.department = department;
    }
}
class Doctor extends HospitalMember {
    public Doctor(String memberId, String name, String department) {
        super(memberId, name, department);
    }
    public double calculateConsultationFee(int patients, double feePerPatient) {
        return patients * feePerPatient;
    }
}

class Nurse extends HospitalMember {
    public Nurse(String memberId, String name, String department) {
        super(memberId, name, department);
    }
    public int calculateDutyHours(int shifts, int hoursPerShift) {
        return shifts * hoursPerShift;
    }
}

public class HospitalSystem {
    public static void main(String[] args) {
        // Create a Doctor object
        Doctor drSharma = new Doctor("D101", "Dr. Sharma", "Cardiology");
        double consultationFee = drSharma.calculateConsultationFee(10, 500.0);

        System.out.println("Doctor Details:");
        System.out.println("ID: " + drSharma.memberId);
        System.out.println("Name: " + drSharma.name);
        System.out.println("Department: " + drSharma.department);
        System.out.println("Consultation Fee for 10 patients: ₹" + consultationFee);

        System.out.println();

        // Create a Nurse object
        Nurse nurseKiran = new Nurse("N202", "Kiran", "Emergency");
        int dutyHours = nurseKiran.calculateDutyHours(5, 8);

        System.out.println("Nurse Details:");
        System.out.println("ID: " + nurseKiran.memberId);
        System.out.println("Name: " + nurseKiran.name);
        System.out.println("Department: " + nurseKiran.department);
        System.out.println("Total Duty Hours for 5 shifts: " + dutyHours + " hours");
    }
}

package cdac;
	public class PersonSystem {
	    public static void main(String[] args) {
	        Student s = new Student("Amit", 20, 101);
	        s.display();
	        System.out.println("Grade: " + s.calculateGrade(85));

	        Teacher t = new Teacher("Mrs. Rao", 45, 201);
	        t.display();
	        System.out.println("Salary: ₹" + t.calculateSalary(40, 500));
	    }
	}
	 class Person {
	    String name;
	    int age;
	    int id;

	    public Person(String name, int age, int id) {
	        this.name = name;
	        this.age = age;
	        this.id = id;
	    }

	    void display() {
	        System.out.println("Name: " + name + ", Age: " + age + ", ID: " + id);
	    }
	}

	class Student extends Person {
	    public Student(String name, int age, int id) {
	        super(name, age, id);
	    }

	    public String calculateGrade(int marks) {
	        if (marks >= 90) return "A";
	        else if (marks >= 75) return "B";
	        else if (marks >= 60) return "C";
	        else return "D";
	    }
	}

	class Teacher extends Person {
	    public Teacher(String name, int age, int id) {
	        super(name, age, id);
	    }

	    public double calculateSalary(int hoursWorked, int ratePerHour) {
	        return hoursWorked * ratePerHour;
	    }
	}


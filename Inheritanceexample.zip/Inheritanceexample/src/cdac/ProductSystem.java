package cdac;

import cdac.Product.Electronics;
import cdac.Product.Clothing;

public class ProductSystem {
    public static void main(String[] args) {
        Electronics laptop = new Electronics("E101", "Laptop", 75000.00);
        laptop.applyWarranty(2);
        laptop.display();

        System.out.println();

        Clothing tshirt = new Clothing();
        double discountedPrice = tshirt.applyDiscount(15);
        tshirt.display(discountedPrice);
    }
}
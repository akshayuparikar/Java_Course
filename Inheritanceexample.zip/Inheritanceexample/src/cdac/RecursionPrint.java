package cdac;

public class RecursionPrint 
{
   public static void printIncreasing(int n)
   {
	        if (n == 0) 
	        	return;
	        printIncreasing(n - 1);
	        System.out.print(n);
   }

	    public static void printIncreasing(int si, int ei) {
	        if (si > ei) 
	        	return;
	        System.out.print(si);
	        printIncreasing(si + 1, ei);
	    }

	    public static void printDecreasing(int n) {
	        if (n == 0) 
	        	return;
	        System.out.print(n);
	        printDecreasing(n - 1);
	    }

	    public static void printIncresingDecresing(int si, int ei) {
	        if (si > ei) 
	        	return;
	        System.out.print(si);
	        printIncresingDecresing(si + 1, ei);
	        System.out.print(si);
	    }

	    public static void printDecresingIncresing(int n) {
	        if (n == 0) 
	        	return;
	        System.out.print(n+" ");
	        printDecresingIncresing(n - 1);
	        
	        System.out.print(n+" ");
	    }
	    public static void main(String[] args) {
	        System.out.println("Print Increasing from 1 to 5:");
	        printIncreasing(5);
	        System.out.println("\nPrint Increasing from 3 to 7:");
	        printIncreasing(3, 7);
	        System.out.println("\nPrint Decreasing from 5 to 1:");
	        printDecreasing(5);
	        System.out.println("\nPrint Increasing then Decreasing from 1 to 3:");
	        printIncresingDecresing(1, 3);            
	        System.out.println("\nPrint Decreasing then Increasing from 3 to 1 and back:");
	        printDecresingIncresing(3);
	    }
}
package cdac;

public class StudentSystem {

    public static void main(String[] args) {
        Student1 s = new Student1(101, "N", 79);
        s.display();
        
        Grade g = new Grade(0, null, 0);
        g.display();
        g.calculate();
    }

     static class Student1 {
        int id;
        String name;
        int mark;

        public Student1(int id, String name, int mark) {
            this.id = id;
            this.name = name;
            this.mark = mark;
        }

        void display() {
            System.out.println("ID: " + id + ", Name: " + name + ", Mark: " + mark);
            System.out.println();
        }
    }

     static class Grade extends Student1 {
        int per;

        public Grade(int id, String name, int mark) {
            super(id, name, mark);
        }

        void calculate() {
            per = mark + 100; // You might want to revise this logic
            System.out.println("Calculated Percentage: " + per);
        }
    }
}

package cdac;

	public class VehicleSystem {
	    public static void main(String[] args) {
	        Car car = new Car(100, "Ford", 2000);
	        car.display();
	        car.totalrent(7);

	        Bike bike = new Bike(101, "Yamaha", 500);
	        bike.display();
	        bike.totalrent(7);
	    }
	
}

	class Vehicle {

	    int vid;
	    String brand;
	    double rentday;

	    public Vehicle(int vid, String brand, double rentday) {
	        this.vid = vid;
	        this.brand = brand;
	        this.rentday = rentday;
	    }

	    void display() {
	        System.out.println("ID: " + vid + ", Brand: " + brand + ", Rent/Day: " + rentday);
	    }
	}

	class Car extends Vehicle {
	    public Car(int vid, String brand, double rentday) {
	        super(vid, brand, rentday);
	    }

	    public void totalrent(int days) {
	        double totalrent = rentday * days;
	        System.out.println("Total Car Rent: " + totalrent);
	    }
	}

	class Bike extends Vehicle {
	    public Bike(int vid, String brand, double rentday) {
	        super(vid, brand, rentday);
	    }

	    public void totalrent(int days) {
	        double totalrent = rentday * days;
	        System.out.println("Total Bike Rent: " + totalrent);
	    }
	}


/**
 * 
 */
/**
 * 
 */
module Inheritanceexample {
}
package cdac;

import java.util.ArrayList;

public class ArrayListExample
{

	public static void main(String[] args) 
	{
	
		ArrayList<Integer> al = new ArrayList<>();
		
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(50);
		System.out.print("After element added");
		for( Integer ele:al)
		{
			System.out.println(ele);
		}
		System.out.println("After adding extra element ");
		al.add(60);
		
		for( Integer ele:al)
		{
			System.out.println(ele);
		}
		
		al.remove(3);
		System.out.println("after remove");
		
		for( Integer ele:al)
		{
			System.out.println(ele);
		}
		
		al.set(2, 105);
		
		System.out.println("after update");
		
		for( Integer ele:al)
		{
			System.out.println(ele);
		}
		
		System.out.println("after insert");
		al.add(1, 5);
		
		for( Integer ele:al)
		{
			System.out.println(ele);
		}	
	}
}

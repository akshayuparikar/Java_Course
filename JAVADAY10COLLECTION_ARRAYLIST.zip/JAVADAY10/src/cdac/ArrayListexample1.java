package cdac;

import java.util.ArrayList;

public class ArrayListexample1 {

	public static void main(String[] args) {
		ArrayList <Integer> al= new ArrayList<>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);
		
		//Added elements
		System.out.println("Entered Elements:");
		
		for (Integer ele:al) 
		{
			System.out.print(ele+" ");
		}
		
		//Add at last
	    al.addLast(60);
	    System.out.println("Entered Elements:");
		for (Integer ele:al)
		{
			System.out.print(ele+" ");
	   
		}
		//remove 
		al.remove(3);
		System.out.println("After Delete Element:");
		for (Integer ele:al)
		{
			System.out.print(ele+" ");
		}
		//
	}

}

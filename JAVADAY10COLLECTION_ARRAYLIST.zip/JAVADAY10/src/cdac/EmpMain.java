package cdac;

import java.util.ArrayList;

public class EmpMain
{

	public static void main(String[] args) 
	{
	
		EmpManagement em = new EmpManagement();
		
		ArrayList<Employee> al =em.createEmpObject();
	    em.displayEmp(al);
		em.updateEmp(al);
		System.out.println("after update");
		em.displayEmp(al);
		em.deleteEmp(al);
		System.out.println("after delete");
		em.displayEmp(al);
		
	}
}

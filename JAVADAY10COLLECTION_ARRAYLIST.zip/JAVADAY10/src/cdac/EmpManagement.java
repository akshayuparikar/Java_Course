package cdac;

import java.util.ArrayList;
import java.util.Scanner;

public class EmpManagement
{

	public ArrayList<Employee> createEmpObject() 
	{
	
		ArrayList<Employee> al = new ArrayList<>();
		
		Employee e1 = new Employee(1002,"shan",40000);
		Employee e2 = new Employee(1003,"nathan",50000);
		Employee e3 = new Employee(1004,"nsnathan",60000);
		
		al.add(e1);
		al.add(e2);
		al.add(e3);
		
		return al;
		
		
	}

	public void displayEmp(ArrayList<Employee> al) 
	{
		
		for(Employee obj : al)
		{
			obj.displayEmployee();
			
			
		}
			
			
		
	}

	public void updateEmp(ArrayList<Employee> al) 
	{
		Scanner s = new Scanner(System.in);
		System.out.println("enter the empno");
	    int eid = s.nextInt();
	    
	    
	    for(Employee obj : al)
		{
			if(obj.empno == eid)
			{
				obj.sal = obj.sal+3000;
			}
			
			
		}
	    
		
	}

	public void deleteEmp(ArrayList<Employee> al) 
	{
	     int pos =0;
		Scanner s = new Scanner(System.in);
		System.out.println("enter the empno to delete");
	    int eid = s.nextInt();
	    
	    
	    for(Employee obj : al)
		{
			if(obj.empno == eid)
			{
				pos = al.indexOf(obj);
			}
			
			
		}
		al.remove(pos);
		System.out.println(eid + "is removed");
		
	}

	
	
}

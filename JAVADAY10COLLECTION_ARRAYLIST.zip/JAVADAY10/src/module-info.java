/**
 * 
 */
/**
 * 
 */
module JAVADAY10 {
}
package cdac;

public class Book 
{
   int bid;
   String bname;
   float bprice;
public Book(int bid, String bname, float bprice) {
	
	this.bid = bid;
	this.bname = bname;
	this.bprice = bprice;
}
@Override
public String toString() {
	return "Book [bid=" + bid + ", bname=" + bname + ", bprice=" + bprice + "]";
}
   

//void dispBook()
//{
//	System.out.println(bid+bname+bprice);
//}
   
   
	
}

package cdac;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class HashMapBook
{

   public static void main(String[] args) 
   {
	
	   Book b1 = new Book(1001,"C programming",4000);
	   Book b2 = new Book(1002,"Python programming",4000);
	   Book b3 = new Book(1003,"Java programming",4000);
	   
	   HashMap<Integer, Book> hm = new HashMap<>();
	   
	   hm.put(b1.bid, b1);
	   hm.put(b2.bid, b2);
	   hm.put(b3.bid, b3);
	   
	   System.out.println("-----------------------------");
	   
	   System.out.println(hm);
	   
	   
	   
	   System.out.println("---------------------------------");
	  
	   
	   for(Map.Entry<Integer, Book> m :hm.entrySet())
			
		{
			System.out.print(m.getKey()+"  ");
		     System.out.println(m.getValue());
			
//			Book obj=m.getValue();
//			obj.dispBook();
			
		}
	
           for(Integer  key :hm.keySet())
           {
        	   System.out.println(key );
           }
   
   System.out.println("-------------------------------");
           for(Book  obj :hm.values())
           {
        	   System.out.println(obj );
           }
   
           
           System.out.println("-------------------------------");
           
           
           
           Book b=hm.get(1001);
           System.out.println(b);
           
           
           System.out.println("enter the book id to delete");
           Scanner s = new Scanner(System.in);
           int id = s.nextInt();
           hm.remove(id);
           System.out.println("book id "+ id + "deleted");
           
           
           for(Map.Entry<Integer, Book> m :hm.entrySet())
   			
   		{
   			System.out.print(m.getKey()+"  ");
   		     System.out.println(m.getValue());
   			

   			
   		}
   			
           System.out.println("-------------------------------");
           
           
           System.out.println("enter the book id to update");
           
            id = s.nextInt();
            
            Book obj = hm.get(id);
            obj.bprice = 700;
            System.out.println(id + "price updated");
            for(Map.Entry<Integer, Book> m :hm.entrySet())
       			
       		{
       			System.out.print(m.getKey()+"  ");
       		     System.out.println(m.getValue());
       			

       			
       		}
           
   }
   
   
	   
	   
   
   
   
   
}	
	


package cdac;

import java.util.HashMap;
import java.util.Map;

public class HashMapExample 
{

	public static void main(String[] args) 
	{
	
		HashMap<Integer, String> hm = new HashMap<>();
		
		hm.put(1,"acts pune dac" );
		hm.put(2,"sunbeam pune dac" );
		hm.put(3,"acts blr  dac" );
		hm.put(4,"vita mumbai  dac" );
		hm.put(5,"iacst pune  dac" );
		
		
		for(Map.Entry<Integer, String> m :hm.entrySet())
	
		{
			System.out.println(m.getKey() + " " +m.getValue());
			
			
			
		}
		
		
		String ele=hm.get(4);
		System.out.println(ele);
		
		hm.put(4, "cdac hyd dac");
		
		System.out.println("------------------------------------");
		for(Map.Entry<Integer, String> m :hm.entrySet())
			
		{
			System.out.println(m.getKey() + " " +m.getValue());
			
			
			
		}
		System.out.println("------------------------------------");
		hm.remove(4);
		
for(Map.Entry<Integer, String> m :hm.entrySet())
			
		{
			System.out.println(m.getKey() + " " +m.getValue());
			
			
			
		}
	}
	
	
}

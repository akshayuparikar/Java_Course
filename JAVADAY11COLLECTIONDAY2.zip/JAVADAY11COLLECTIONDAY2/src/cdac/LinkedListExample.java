package cdac;

import java.util.LinkedList;

public class LinkedListExample 
{

	public static void main(String[] args) 
	{
	
		LinkedList<Integer> ll = new LinkedList<>();
		
		ll.add(10);
		ll.add(20);
		ll.add(30);
		ll.add(40);
		ll.add(50);
		
		System.out.println("Added------------------------");
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		
		System.out.println("Add at first and last element------------------------");
		ll.addFirst(5);
		ll.addLast(100);
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		
		System.out.println("Add at particular element------------------------");
		ll.add(2,200);
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		
		System.out.println("Update element at particular position------------------------");
		ll.set(2, 300);
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
		
		
		System.out.println("Remove Element at particular position-----------");
		ll.remove(2);
		for(Integer ele :ll)
		{
			System.out.println(ele);
		}
	}
}

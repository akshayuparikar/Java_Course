package cdac;

import java.util.PriorityQueue;

public class QueueExample 
{

	public static void main(String[] args) 
	{
	
		PriorityQueue<Integer> p = new PriorityQueue<>();
		
		p.add(10);
		p.add(20);
		p.add(30);
		p.add(40);
		p.add(50);
		
		for(Integer ele :p)
		{
			System.out.println(ele);
		}
		System.out.println("------------------------------");
		Integer ele = p.poll();
		
		System.out.println(ele);
		System.out.println("------------------------------");
		for(Integer ele1 :p)
		{
			System.out.println(ele1);
		}
		
		System.out.println("------------------------------");
		p.remove(20);		
		for(Integer obj :p)
		{
			System.out.println(obj);
		}
		
	}
	
	
}

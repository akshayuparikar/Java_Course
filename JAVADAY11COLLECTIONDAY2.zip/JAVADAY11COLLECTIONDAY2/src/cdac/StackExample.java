package cdac;

import java.util.Stack;

public class StackExample 
{

	
	public static void main(String[] args) 
	{
	
		Stack<Integer> s = new Stack<>();
		
		s.push(10);
		s.push(20);
		s.push(30);
		s.push(40);
		s.push(50);
		
		for(Integer ele :s)
		{
			System.out.println(ele);
		}
		System.out.println("---------------------------");
		
		Integer ele= s.pop();
		System.out.println(ele);
		
		
		s.add(3,100);
		System.out.println("---------------------------");
		
		for(Integer ele1 :s)
		{
			System.out.println(ele1);
		}
		
		
		s.remove(3);
		for(Integer ele1 :s)
		{
			System.out.println(ele1);
		}
		
		System.out.println(s.isEmpty());
		
		System.out.println("--------------------");
		
		
		String n = "10";
		
		String m = "20";
		
		Integer c = Integer.parseInt(n)+Integer.parseInt(m);
		
		System.out.println(c);
		
		
		
		
		
				
	}
	
	
}

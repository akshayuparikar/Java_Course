package cdac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PreparedStatementUpdate {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/empsys", "root", "Akshay@1008");

		System.out.println("got connection");

		// update

		String q = "update emp set sal = sal + ? where empno = ?";

		System.out.println("enter the id,sal");
		Scanner s = new Scanner(System.in);
		int id = s.nextInt();
		float sa = s.nextFloat();

		PreparedStatement pmt = con.prepareStatement(q);

		pmt.setFloat(1, sa);
		pmt.setInt(2, id);

		int nor = pmt.executeUpdate();

		System.out.println("updated");

		// select

		String q1 = "select * from emp where empno = ?";

		pmt = con.prepareStatement(q1);

		id = s.nextInt();

		pmt.setInt(1, id);

		ResultSet rs = pmt.executeQuery();

		while (rs.next()) {
			System.out.println(rs.getInt("empno") + rs.getString("ENAME") + rs.getFloat("SAL"));
		}
        
		//delete
		System.out.println("enter the id to delete");

		id = s.nextInt();

		String q2 = "delete from emp where empno = ?";

		pmt = con.prepareStatement(q2);
		pmt.setInt(1, id);
		int no = pmt.executeUpdate();

		System.out.println("deleted ");

		// insert

		System.out.println("Enter the values: empno , ename , sal");
		int eno = s.nextInt();
		String nm = s.next();
		float sal = s.nextFloat();
		String q3 = "insert into emp(empno,ename,sal) values(?,?,?);";

		pmt = con.prepareStatement(q3);
		pmt.setInt(1, eno);
		pmt.setString(2, nm);
		pmt.setFloat(3, sal);

		int no1 = pmt.executeUpdate();
		System.out.println(no1 + "Inserted" );

		pmt.close();
		con.close();

	}

}

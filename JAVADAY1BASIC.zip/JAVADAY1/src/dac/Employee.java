package dac;

public class Employee 
{
    int eno;
    String name;
    
       
   public void displayemp()
    {
    	
    System.out.println(eno);
    System.out.println(name);
    	
    }
    
    public void print()
    {
    	System.out.println(++eno);
        System.out.println(name.toUpperCase());
    }
    
    public static void main(String[] args)
    {
    	Employee e = new Employee();
    	e.eno = 1001;
    	e.name = "nsnathan";
    	e.displayemp();
    	e.print();
    	
    }
}

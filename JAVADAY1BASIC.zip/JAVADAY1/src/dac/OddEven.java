package dac;

public class OddEven 
{
public static void main(String[] args) 
{

	int num = 30;
	
	if(num%2 == 0)
	{
		System.out.println("the given num is even");
	}else
		System.out.println("the given num is odd");
	
}
}

package dac;

public class Student 
{

	public static void main(String[] args)
	{
		int sid= 1001;
		String name = "nsnathan";
		int lmark = 16;
		int cmark = 17;
		String result = null;
		float per = 80.4f;
		char grade;
		if(lmark>=16 && cmark>16)
		{
			result = "pass";
		}else
			result = "fail";
		
		
		if(per>90)
		{
			grade = 'A';
		}
			
		else if(per >80)
		{
			grade = 'B';
		}
		
		else if(per >60)
		{
			grade = 'C';
		}
		
		else if(per >50)
		{
			grade = 'D';
		}
		else
		{
			grade = 'F';
		}
		

		System.out.println(sid);
		System.out.println(name);
		System.out.println(lmark);
		System.out.println(cmark);
		System.out.println(result);
		System.out.println(grade);
			
	}
	
	
}

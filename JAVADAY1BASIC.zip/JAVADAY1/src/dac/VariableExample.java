package dac;

public class VariableExample
{

  public static void main(String[] args) 
  {
	
	  
	    int sid= 1001;
		String name = "nsnathan";
		int mark = 40;
		float per = 8.5f;
		char grade = 'A';
		boolean joined = false;
		
		if(joined)
		{
		System.out.println(sid);
		System.out.println(name);
		System.out.println(mark);
		System.out.println(per);
		System.out.println(grade);
		System.out.println(joined);
		}
		else
		{
		   System.out.println("employee is not available");	
		}
	  
}
  
  	
}



public class add
{

	public static void main(String[] args)
	{
	
		int n1 = 20;
		int n2 = 30;
		int sum = n1+n2;
		System.out.println("sum of n1 and n2 is "+sum);
		
		
	}
	
}

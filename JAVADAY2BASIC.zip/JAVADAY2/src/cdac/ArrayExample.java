package cdac;

import java.util.Scanner;

public class ArrayExample 
{

	public static void main(String[] args) 
	{
	
		int[] num = new int[5];
		
		Scanner s = new Scanner(System.in);
		for(int i=0;i<5;i++)
		{

		num[i]= s.nextInt();
		   
		}
//		num[0] = 10;
//		num[1] = 20;
//		num[2] = 30;
//		num[3] = 40;
//		num[4] = 50;
		
		for(int i=0;i<5;i++)
		{

		System.out.println(num[i]);
		   
		}


		
		
	}
	
}

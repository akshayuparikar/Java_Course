package cdac;

import java.util.Scanner;

public class CalculaterExample 
{
	public static int calculater(int a, int b, int ch) 
	{  
		int res=0;
	
		switch(ch)
		{
		case 1: res = a+b;
		break;
		case 2: res = a-b;
		break;
		default: System.out.println("invalid");
		break;
		}
		return res;
	}
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		int a;
		int b;
		
		System.out.println("1-> add");
		System.out.println("2->  subtraction");
		System.out.println("enter the value of a ,b");
		a = s.nextInt();
		b = s.nextInt();
		System.out.println("enter the choice ");
		int ch = s.nextInt();
		int res=calculater(a,b,ch);
		System.out.println(res);
		
		
		
		
		
		
		
	}

	
	
	
}

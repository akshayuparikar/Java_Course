package cdac;

public class Employee 
{

	public static void Greetings()
	{
		System.out.println("inside the greetings of Employee class");
	}
	
	
}

package cdac;

public class MethodExample
{
	public static void sayHello(String name)
	{
		System.out.println(" Hello  "  + name);
		
	}
	
	public static void main(String[] args) 
	{
	    String name = "nsnathan";
	    MethodExample.sayHello(name);
		System.out.println("end of main");
		
		
	}
	
	
}

package cdac;

import java.util.Scanner;

public class ReadEmpDetails 
{
	
	public static String findResult(int mark)
	{String result;
		if(mark >16)
			result = "pass";
		else
			result = "fail";
		
		return result;
		
		
	}
	

	public static void main(String[] args) 
	{
	
		int sid;
		int mark;
		String name;
		float per;
		byte b;
		//b = 500;
		//int mobile = 9008282882;
		long mobile = 9008282882l;
		Scanner s = new Scanner(System.in);
		System.out.println("enter studet details");
		
		sid =s.nextInt();
		name = s.next();
		per = s.nextFloat();
		mark = s.nextInt();
		
		String res = findResult(mark);
		
		System.out.println("student id : "+sid);
		System.out.println("student name : " +name);
		System.out.println("student percentage: " +per);
		System.out.println("student mark: " + mark);
		System.out.println("student result " + res);
		
		
		
		
		
		
		
		
		
	}
	
	
}

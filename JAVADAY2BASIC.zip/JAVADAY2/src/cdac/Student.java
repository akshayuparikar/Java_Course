package cdac;

public class Student 
{
        public void findResult()
        {
        System.out.println("result will be found here");
        }
	
	
	
}

package cdac;

public class TernaryExample
{

	public static void main(String[] args) 
	{
	
		int a =20;
		int b = 10;
		
		   String res = (a>b)? "a is big" : "b is big";
		   System.out.println(res);
		
	}
	
}

package cdac;

public class Test
{

	public static void main(String[] args) 
	{
	
		Employee.Greetings();
		
	}
	
}

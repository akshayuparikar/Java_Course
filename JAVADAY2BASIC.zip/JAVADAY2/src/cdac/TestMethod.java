package cdac;

import java.util.Scanner;

public class TestMethod 
{

	public static String eligible(int age)
	{
		String res;
		if(age>18)
			res = "eligible";
		else
			res = "not eligible";
		return res;
	}
	
	
	public static void main(String[] args) 
	{
	
       String name;
       int age;
       
       Scanner s = new Scanner(System.in);
       name = s.next();
       age = s.nextInt();
       
   String res=    eligible(age);
   System.out.println(name);
   System.out.println(age);
   System.out.println(res);
       
      
       
       
		
	}
	
}

package cdac;

public class UnaryOperatorExample 
{

	public static void main(String[] args) 
	{
	
//		int a = 0;
//		System.out.println(a);
//		System.out.println(a++);
//		System.out.println(++a);
		
		int a = 0;
		
		int b = a + a++ + a--;
		
		System.out.println(b);
		
		
		
		
		
	}
	
	
	
}

/**
 * 
 */
/**
 * 
 */
module JAVADAY2 {
}
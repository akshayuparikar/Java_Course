package cdac;

public class ArrayExample 
{

	public static int findmax(int[] num)
	{
		int sum=0;
//		for(int i = 0;i<num.length;i++)
//		{
//			System.out.println(num[i]);
//			sum = sum+num[i];
//			
//		}
		
		int max = num[0];
		for(int i = 0;i<num.length;i++)
		{
			if(num[i]>max)
			{
				max = num[i];
			}
			
		}
		
		
		return max;
		
	}
	
	
	
	
	public static void main(String[] args) 
	{
	
		//int[] n = new int[4];
		int[] num = { 10,20,30,40,50};
		

		//int sum = findsum(num);
		//System.out.println("sum of the array element is "+sum);

		int max = findmax(num);
		System.out.println("max element from the array "+max);
		
	}

	
	
	
}

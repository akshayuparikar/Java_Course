package cdac;

public class ChangeinNonPrimitives 
{

	public static void change(int[] num)
	{
			   	
		  num[2]= 100;
		
	}
	
	
	
	public static void main(String[] args) 
	{
	
		int[] num = { 10,20,30,40,50};
		
		
		
		for(int i = 0;i<num.length;i++)
		{
			System.out.println(num[i]);
					
		}
		
		change(num);
		System.out.println("after change method");
		for(int i = 0;i<num.length;i++)
		{
			System.out.println(num[i]);
					
		}
		
		
		
	}

	
	
	
}

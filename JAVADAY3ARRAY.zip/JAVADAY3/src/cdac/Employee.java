package cdac;

import java.util.Scanner;

public class Employee 
{
     int empno;
     String name;
     float sal;
     String designation;
     
     public void getEmployeedata()
     {
    	 Scanner s = new Scanner(System.in);
    	 
    	 empno = s.nextInt();
    	 name = s.next();
    	 sal = s.nextFloat();
    	 designation = s.next();
    	 
     }
     
	public void displayEmployee()
	{
		System.err.println(empno);
		System.out.println(name);
		System.out.println(sal);
		System.out.println(designation);
		
		
	}
	
	public void increseSal()
	{
		sal = sal+1000;
		
	}
	
     public static void main(String[] args) 
     {
	     System.out.println("first object");
    	 Employee e = new Employee();
//    	 e.empno = 1001;
//    	 e.name = "shan";
//    	 e.sal = 30000;
//    	 e.designation = "faculty";
    	 
//    	 System.out.println(e.empno);
//    	 System.out.println(e.name);
//    	 System.out.println(e.sal);
//    	 System.out.println(e.designation);
    	 e.getEmployeedata();
    	 System.out.println("before increase");
    	 e.displayEmployee();
    	 e.increseSal();
    	 System.out.println("after increase");
    	 e.displayEmployee();
    	 
    	  System.out.println("second object");
    	 Employee e1 = new Employee();
//    	 e1.empno = 1002;
//    	 e1.name = "raj";
//    	 e1.sal = 40000;
//    	 e1.designation = "admin";
    	 
//    	 System.out.println(e1.empno);
//    	 System.out.println(e1.name);
//    	 System.out.println(e1.sal);
//    	 System.out.println(e1.designation);
    	
    	 e1.getEmployeedata();
    	 e1.displayEmployee();
    	 
	 }
     
	
}

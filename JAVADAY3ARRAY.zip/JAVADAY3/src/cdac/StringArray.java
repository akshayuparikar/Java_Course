package cdac;

import java.util.Scanner;
import java.lang.String;
import java.lang.System;

public class StringArray 
{
      
	public static void printArray(String[] sub)
	{
		System.out.println(sub[0]);
		
	}
	
	
	public static void main(String[] args) 
	{
		System.out.println(args[0]);
		System.out.println(args[1]);
	
		String[] sub= {"c++","Java","dbt","python"};
		
		//Scanner s = new Scanner(System.in);
		
		
		printArray(sub);
		
		
	}

	
	
	
}

package cdac;

import java.util.Scanner;

public class sumofdigit 
{
	public static void sumofgivendigit(int num) 
	{
	int digit=0;
	int sum =0;
		while(num !=0 )
		{
			
          digit = num%10;
          num = num/10;
          sum = sum +digit;
	      		
			
		}
		System.out.println(sum);
		
		
	}
	
	public static void main(String[] args) 
	{		
	
		Scanner s = new Scanner(System.in);
		int num;
		num = s.nextInt();
		sumofgivendigit(num);
		
		
	
	}

	
	
}

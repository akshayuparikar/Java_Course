/**
 * 
 */
/**
 * 
 */
module JAVADAY3 {
}
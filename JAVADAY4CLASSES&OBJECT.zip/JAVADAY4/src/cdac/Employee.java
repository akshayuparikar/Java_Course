package cdac;
import java.util.Scanner;

class Employee
{
   int empno;
   String name;
   float sal;
   
   void readEmployee(int eno ,String na,float sa)
   {   
   empno = eno;
   name = na;
   sal = sa;	   
   }
   
   void dispEmployee()
   {
	   System.out.println(name);
		System.out.println(empno);
		System.out.println(sal);	   
	   
   }

public class Employeenew
{
		public static void main(String[] args) 
		{
			Employee e1 = new Employee();
			Employee e2 = new Employee();
			
			e1.readEmployee(1001,"nsnathan",40000);
			e2.readEmployee(1002,"shan",500000);
			e1.dispEmployee();
			e1.dispEmployee();
		
		}
}
}	
	



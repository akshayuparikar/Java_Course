package cdac;

public class Product 
{
   int pid;
   String pname;
   float price;
public Product(int pid, String pname, float price)
{
	
	this.pid = pid;
	this.pname = pname;
	this.price = price;
}
   

void displayProduct()
{
	
	System.out.println(pid+pname+price);
	
}

   
   
	
	
}

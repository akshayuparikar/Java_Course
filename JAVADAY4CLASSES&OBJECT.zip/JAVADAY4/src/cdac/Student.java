package cdac;

public class Student
{

	int sid;
	String name;
	int mark;
	
	Student()
	{
		sid = 1003;
		name = "krishna";
		mark = 50;
		//this.displayStudent();
	}
	Student(int sid,String name,int mark)
	{
		this.sid = sid;
		this.name = name;
		this.mark = mark;
		//this.displayStudent();
	}
	void displayStudent()
	{
		System.out.println(sid);
	    System.out.println(name);
	    System.out.println(mark);
	}

public class TestStudent 
{
public static void main(String[] args) 
{

	Student s1 = new Student(1001,"nsnathan",40000);
	
	s1.displayStudent();
	
    Student s2 = new Student(1002,"raj",50000);
	
	s2.displayStudent();
	
//	Student s3 = new Student();
//	
//	s3.displayStudent();
}
	
}

}

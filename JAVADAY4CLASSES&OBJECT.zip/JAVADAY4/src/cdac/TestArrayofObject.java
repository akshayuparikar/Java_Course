package cdac;

import java.util.Scanner;

public class TestArrayofObject
{

	public static void main(String[] args) 
	{
	
		Product[] p = new Product[3];
		Scanner s = new Scanner(System.in);
		
		for(int i =0;i<p.length;i++)
		{
		p[i] = new Product(s.nextInt(),s.next(),s.nextFloat());
		}
		
		
		for(int i =0;i<p.length;i++)
		{
			p[i].displayProduct();
		}
		
		
		
		
		
		
		
		
		
	}
	
}

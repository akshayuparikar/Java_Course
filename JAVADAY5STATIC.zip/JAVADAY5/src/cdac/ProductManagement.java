package cdac;

import java.util.Scanner;

public class ProductManagement
{

	public void displayproducts(Product[] p)
	{
		
		for(int i =0;i<p.length;i++)
		{
			p[i].displayProduct();
		}
		
	}

	public Product[] createproduct() 
	{
		Product[] p = new Product[3];
		Scanner s = new Scanner(System.in);
		for(int i =0;i<p.length;i++)
		{
		p[i] = new Product(s.nextInt(),s.next(),s.nextFloat());
		}
		
		return p;
		
	}

	public void updateproducts(Product[] p)
	{
		
		Scanner s = new Scanner(System.in);
		System.out.println("enter the prodcut id to update the price");
        int id = s.nextInt();
        for(int i =0;i<p.length;i++)
		{
			if(p[i].pid == id)
			{
				p[i].price = 70000;
			}
		}
		
	}
	
	
}

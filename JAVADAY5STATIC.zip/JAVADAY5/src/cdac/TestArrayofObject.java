package cdac;

import java.util.Scanner;

public class TestArrayofObject
{

	public static void main(String[] args) 
	{
		ProductManagement pm = new ProductManagement();
	  	
		System.out.println("1: create Product");
		System.out.println("2: display Product");
		
		Product[] p =pm.createproduct();
		System.out.println("before update");
		pm.displayproducts(p);
		pm.updateproducts(p);
		System.out.println("after update the product");
		pm.displayproducts(p);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
}

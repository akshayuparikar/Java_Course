/**
 * 
 */
/**
 * 
 */
module JAVADAY5 {
}
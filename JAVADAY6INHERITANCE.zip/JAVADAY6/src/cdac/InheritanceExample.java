package cdac;
class vehicle
{
	String brand = "Ford";
	
	
void start()
{
	System.out.println("vehicle is starting");
}
	
}
class Car extends vehicle
{
	int wheels = 4;
	
	void displayCar()
	{
		System.out.println(wheels);
		System.out.println(brand);
	}
	
	
	
}



public class InheritanceExample
{

	public static void main(String[] args) 
	{
		Car c = new Car();
		c.start();
		c.displayCar();
		
		
		
	} 
	
	
}

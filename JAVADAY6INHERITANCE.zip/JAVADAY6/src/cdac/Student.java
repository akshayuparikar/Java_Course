package cdac;

public class Student 
{
     int sid;
     String name;
     int mark;
	 static String cname;
	public Student(int sid, String name, int mark ) {
		
		this.sid = sid;
		this.name = name;
		this.mark = mark;
		
	}
	 
	static void readcname()
	{    
		cname = "dac";
		
	}
	
	
	void dispStudent()
	{
		System.out.println(sid+name+mark+cname);
	}
	 
	 
	 
	 
	 
  
}

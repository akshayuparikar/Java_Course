package cdac;

public class StudentMain
{

	public static void main(String[] args) 
	{
	
		Student s1 = new Student(1001,"raj",30);
		Student s2 = new Student(1002,"shan",20);
		Student s3 = new Student(1003,"nsnathan",40);
	
		
		
		Student.readcname();
		s1.dispStudent();
		s2.dispStudent();
		
		Student.readcname();
		s3.dispStudent();
	}
	
}

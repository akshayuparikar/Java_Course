package cdac;

class A
{
	
	void print()
	{
		System.out.println("class A print method");
	}
	
	
}

class B extends A
{
	void show()
	{
		System.out.println("class B show method");
	}
	
	
	
}


public class Testinheritace 
{

	public static void main(String[] args) 
	{
		
		B b = new B();
		b.show();
		b.print();
		
	}
	
}

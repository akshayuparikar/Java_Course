/**
 * 
 */
/**
 * 
 */
module JAVADAY6 {
}
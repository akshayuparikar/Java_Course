package cdac;

public class A 
{    int i;


    A()
    { i =5;
    	System.out.println("A no org cons" +i);
    }
    
	A(int i)
	{
		this();
		this.i = i;
	}
	
	void dispA()
	{
		System.out.println(i);
	}
}

class B extends A
{
	
	int j;;

	B()
	{
		System.out.println("no arg B");
	}
	B(int i,int j)
	
	{    
		this();
		
		this.j = j;
	}
	
	void dispB()
	{
		System.out.println(j);
	}
		
}

class Test
{
	public static void main(String[] args) {
		
		B b = new B(10,20);
		b.dispA();
		b.dispB();
		
	
	}
}

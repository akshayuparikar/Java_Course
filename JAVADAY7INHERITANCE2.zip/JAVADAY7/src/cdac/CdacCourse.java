package cdac;

class Person
{
	int id;
	String name;
	String add;
	
	public Person(int id, String name, String add) 
	{
		
		this.id = id;
		this.name = name;
		this.add = add;
	}
	void displayPerson()
	{
		System.out.print(id+" "+name+" "+add);
	}

	
	
	
}


class Student extends Person 
{
    	int mark;
    	
    	Student(int id,String name,String address,int mark)
    	{
    		super(id,name,address);
    		this.mark = mark;
    		
    	}
    	
    	void dispStudent()
    	
    	{  //super.displayPerson();
    		
    		System.out.println(id+" "+name+" "+add+" "+mark);
    	}
    	
    	void findResult()
    	{
    		if(mark>16)
    		{System.out.println("pass");
    		
    		}else
    			System.out.println("fail");
    	}
 
}



class Teacher extends Person
{
	float sal;
	
	
	Teacher(int id,String name,String add,int sal)
	{
		super(id,name,add);
		this.sal = sal;
	}
	
	
	void displayTeacher()
	{  
	    super.displayPerson();
	    System.out.print(" ");
		System.out.println(sal);
	}
	
	void findbonus()
	{
		int total=(int) (sal+sal*0.02);
		System.out.println("increased salary:"+total);
	}
	
}


public class CdacCourse 
{
	public static void main(String[] args) 
	{	
		Student s = new Student(1001,"nsnathan","blr",40);
		
		s.dispStudent();
		s.findResult();
		
		Teacher t = new Teacher(1002,"raj","pune",50000);
		t.displayTeacher();
		t.findbonus();	
		}
}

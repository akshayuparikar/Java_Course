package cdac;

public class Address 
{

	String city;
	String state;
	int pin;
	long mobile;
	public Address(String city, String state, int pin, long mobile) {
		
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.mobile = mobile;
	}
	
	void dispAdd()
	{
		System.out.println(city+" "+state+" "+pin+" "+mobile);
	}
	
	
	
	
	
	
}

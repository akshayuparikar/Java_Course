package cdac;

public class Employee 
{

	int empno;
	String name;
	String cname;
	Address add;
	public Employee(int empno, String name, String cname, Address add) {
		
		this.empno = empno;
		this.name = name;
		this.cname = cname;
		this.add = add;
	}
	
	void empdetails()
	{
		System.out.println(empno+" "+name+" "+cname);
		add.dispAdd();
	}
	
	
}

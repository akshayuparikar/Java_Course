package cdac;

public class HasarelationExample
{

	public static void main(String[] args) 
	{
		
		Address add = new Address("blr","karnataka",560638,9003003l);
		
		Employee e = new Employee(1001,"nathan","dac",add);
		
		e.empdetails();
	} 
	
	
	
}

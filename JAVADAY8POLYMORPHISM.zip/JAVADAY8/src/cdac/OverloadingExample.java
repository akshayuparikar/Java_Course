package cdac;

public class OverloadingExample
{

	public static void main(String[] args) 
	{
	
		float a = 10.3f;
		float b = 20.4f;
		calculator.add(a,b);
		
		
		
		
		
		
		
		
	}
	
}

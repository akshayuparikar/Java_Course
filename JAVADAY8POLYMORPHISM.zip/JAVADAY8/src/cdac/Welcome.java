package cdac;

public class Welcome 
{
	  static  void  findoddeven(float num)
	    {
	    	
	    }
	

	public static void main(String[] args)
	{
         int sid = 1001;
          String name = "nsnathan";
          float sal = 4000.4f;
		System.out.println(sid);
         System.out.println(name);
         System.out.println(sal);
         
         
         float num = 30;
         
         findoddeven(num);
         
         
		
	} 
	
	
	
}

package cdac;

public class calculator
{

	static void add(int a,int b)
	{
		System.out.println(a+b);
	}
	
	static void add(float a,float b)
	{
		System.out.println(a+b);
	}
}

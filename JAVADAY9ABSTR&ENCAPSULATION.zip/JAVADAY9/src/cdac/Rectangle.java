package cdac;

public class Rectangle {
	double length;
	double bredth;
	
	public Rectangle(double length, double bredth) {
		
		this.length = length;
		this.bredth = bredth;
	}
	
 double findArea() {
	
	return length*bredth;
 }
	
}

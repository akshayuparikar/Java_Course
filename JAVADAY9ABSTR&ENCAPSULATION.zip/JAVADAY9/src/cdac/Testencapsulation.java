package cdac;
public class Testencapsulation
{
	    public static void main(String[] args) 
	    {
		Student s = new Student();
		s.setSid(1001);
		System.out.println(s.getSid());
		s.setName("nsnathan");
		System.out.println(s.getName());
		
		
	    }
	
}

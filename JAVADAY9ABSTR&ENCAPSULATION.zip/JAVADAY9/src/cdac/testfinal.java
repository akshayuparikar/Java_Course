package cdac;

 class vehicle
{
	
	
	 final void start()
{
	System.out.println("vehicle is starting");
}
	
}

class Car extends vehicle
{
	void display()
	{
		System.out.println("car is starting");
	}
	
	
}


public class testfinal
{
	public static void main(String[] args) 
	{
	
		Car c = new Car();
		c.start();
	}

}

package cdac;

import java.sql.*;
import java.util.Scanner;

public class JDBCExample {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
       
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/empsys", "root", "Akshay@1008");
                 Scanner sc = new Scanner(System.in)) {

                System.out.println("Got Connected Successfully");

                // SELECT operation
                System.out.println("Enter the id to search:");
                int id = sc.nextInt();
                String q = "SELECT * FROM empinfo WHERE id = ?";
                try (PreparedStatement Stmt = con.prepareStatement(q)) {
                    Stmt.setInt(1, id);
                    ResultSet rs = Stmt.executeQuery();
                    if (rs.next()) {
                        System.out.println("ID: " + rs.getInt("id"));
                        System.out.println("Name: " + rs.getString("name"));
                        System.out.println("Per: " + rs.getInt("percentage"));
                    } else {
                        System.out.println("No record found");
                    }
             }
            

                // INSERT operation
                System.out.println("Enter the id to insert:");
                int id1 = sc.nextInt();
                sc.nextInt(); // Consume newline
                System.out.println("Enter the name:");
                String nm = sc.nextLine();
                System.out.println("Enter the per:");
                int per = sc.nextInt();

                String insertQuery = "INSERT INTO empinfo(id, name, percentage) VALUES (?, ?, ?)";
                try (PreparedStatement q1 = con.prepareStatement(insertQuery)) {
                    q1.setInt(1, id1);
                    q1.setString(2, nm);
                    q1.setInt(3, per);
                    int rowsInserted = q1.executeUpdate();
                    System.out.println(rowsInserted + " row(s) inserted.");
                }
            

        
       }
            }}
/**
 * 
 */
/**
 * 
 */
module JDBCPractice {
	requires java.sql;
}